/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package i.ristorante_bolivar;

/**
 *
 * @author ospite
 */
public class cassiere extends Thread {
     private listaord lista;

    public cassiere(listaord lista) {
        this.lista = lista;
    }

    @Override
    public void run() {
        String[] piatti = {"Hamburger", "Patatine", "Pizza", "Insalata", "Coca-Cola"};
        for (int i = 0; i < 10; i++) {
            String piatto = piatti[i % piatti.length];
            int quantita = 1 + (int)(Math.random() * 3);
            String note = "senza sale";
            ordine o = new ordine(piatto, quantita, note);
            lista.inserisciOrdinazione(o);
            System.out.println("[Cassiere] Inserita ordinazione: " + o);
            try {
                Thread.sleep(500); // Simula tempo tra le ordinazioni
            } catch (InterruptedException e) {
                break;
            }
        }
    }
    
}
