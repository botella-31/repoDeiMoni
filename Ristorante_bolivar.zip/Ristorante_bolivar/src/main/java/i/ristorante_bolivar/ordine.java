/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package i.ristorante_bolivar;

/**
 *
 * @author ospite
 */
public class ordine {
    private String piatto;
    private int quantita;
    private String note;

    public ordine(String piatto, int quantita, String note) {
        this.piatto = piatto;
        this.quantita = quantita;
        this.note = note;
    }

    public ordine(ordine o) {
        this.piatto = o.piatto;
        this.quantita = o.quantita;
        this.note = o.note;
    }

    public String getPiatto() {
        return piatto;
    }

    public int getQuantita() {
        return quantita;
    }

    public String getNote() {
        return note;
    }
    
    @Override
    public String toString() {
        return quantita + "x " + piatto + " [" + note + "]";
    }

  
    
}
