/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package i.ristorante_bolivar;

/**
 *
 * @author ospite
 */
public class listaord {
    
    private ordine[] ordinazioni;
    private int indice_inserimento;
    private int indice_estrazione;
    private int numero_ordinazioni;

    public listaord(int numero_massimo_ordinazioni) {
        ordinazioni = new ordine[numero_massimo_ordinazioni];
        indice_inserimento = 0;
        indice_estrazione = 0;
        numero_ordinazioni = 0;
    }

    public synchronized boolean inserisciOrdinazione(ordine o) {
        while (numero_ordinazioni == ordinazioni.length) {
            try {
                wait(); // aspetta spazio disponibile
            } catch (InterruptedException e) {
                return false;
            }
        }
        ordinazioni[indice_inserimento] = new ordine(o);
        indice_inserimento = (indice_inserimento + 1) % ordinazioni.length;
        numero_ordinazioni++;
        notifyAll(); // notifica il cuoco che c'è un'ordinazione
        return true;
    }

    public synchronized ordine estraiOrdinazione() {
        while (numero_ordinazioni == 0) {
            try {
                wait(); // aspetta che ci siano ordinazioni
            } catch (InterruptedException e) {
                return null;
            }
        }
        ordine o = ordinazioni[indice_estrazione];
        indice_estrazione = (indice_estrazione + 1) % ordinazioni.length;
        numero_ordinazioni--;
        notifyAll(); // notifica il cassiere che c'è spazio
        return o;
    }
    
}
