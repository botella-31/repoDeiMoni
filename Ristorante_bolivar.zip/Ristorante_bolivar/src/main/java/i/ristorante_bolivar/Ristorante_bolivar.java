/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package i.ristorante_bolivar;

/**
 *
 * @author ospite
 */
public class Ristorante_bolivar {

    public static void main(String[] args) {
       listaord lista = new listaord(5); // max 5 ordini
        cassiere cassiere = new cassiere(lista);
        cuoco cuoco = new cuoco(lista);

        cassiere.start();
        cuoco.start();
    }
}
