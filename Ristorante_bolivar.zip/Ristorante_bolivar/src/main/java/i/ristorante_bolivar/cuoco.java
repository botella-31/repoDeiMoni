/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package i.ristorante_bolivar;

/**
 *
 * @author ospite
 */
public class cuoco extends Thread {
    
    private listaord lista;

    public cuoco(listaord lista) {
        this.lista = lista;
    }

    
    @Override
    public void run() {
        while (true) {
            ordine o = lista.estraiOrdinazione();
            if (o != null) {
                System.out.println("[Cuoco] Preparo: " + o);
                try {
                    Thread.sleep(1000); // Simula tempo di preparazione
                } catch (InterruptedException e) {
                    break;
                }
            }
        }
    }
    
}
